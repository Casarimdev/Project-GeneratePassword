import Content from "./components/Content/content";
import Tittle from "./components/Tittle/tittle";

function App() {
  return (
    <>
      <Tittle text="Password Generate"></Tittle>
      <Content></Content>
    </>
  );
}

export default App;
